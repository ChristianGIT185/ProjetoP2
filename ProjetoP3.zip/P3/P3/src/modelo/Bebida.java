package modelo;

public class Bebida extends ItemMenu {

    private int tamanhoEmMl;

    public Bebida() {
    }

    public Bebida(int id,
                  String nome,
                  double preco,
                  int tamanhoEmMl) {

        super(id, nome, preco);
        this.tamanhoEmMl = tamanhoEmMl;
    }

    public int getTamanhoEmMl() {
        return tamanhoEmMl;
    }

    public void setTamanhoEmMl(int tamanhoEmMl) {
        this.tamanhoEmMl = tamanhoEmMl;
    }

    @Override
    public double calcularPrecoFinal() {
        return getPreco();
    }
}