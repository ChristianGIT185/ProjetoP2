package modelo;

public class Pizza extends ItemMenu {
    private String ingredientes;

    public Pizza() {}

    public Pizza(int id, String nome, double preco, String ingredientes) {
        super(id, nome, preco);
        this.ingredientes = ingredientes;
    }

    public String getIngredientes() {
        return ingredientes;
    }

    public void setIngredientes(String ingredientes) {
        this.ingredientes = ingredientes;
    }

    @Override
    public double calcularPrecoFinal() {
        return getPreco(); // sem taxa extra por enquanto
    }
}
