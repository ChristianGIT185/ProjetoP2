package conexao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class FabricaConexao {

    private static final String URL =
            "jdbc:mysql://localhost:3306/pizzaria";

    private static final String USUARIO =
            "root";

    private static final String SENHA =
            "ADS@Banco2026";

    public static Connection getConexao()
            throws SQLException {

        return DriverManager.getConnection(
                URL,
                USUARIO,
                SENHA
        );
    }
}