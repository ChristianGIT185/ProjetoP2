package dao;

import conexao.FabricaConexao;
import modelo.*;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ItemMenuDAO {

    public void salvar(ItemMenu item) {

        String sql =
            "INSERT INTO item_menu " +
            "(nome, preco, tipo, ingredientes, tamanho_ml) " +
            "VALUES (?, ?, ?, ?, ?)";

        try (
            Connection conn =
                FabricaConexao.getConexao();

            PreparedStatement stmt =
                conn.prepareStatement(sql)
        ) {

            stmt.setString(1, item.getNome());
            stmt.setDouble(2, item.getPreco());

            if (item instanceof Pizza) {

                Pizza pizza = (Pizza) item;

                stmt.setString(3, "PIZZA");
                stmt.setString(4,
                               pizza.getIngredientes());
                stmt.setNull(5, Types.INTEGER);

            } else if (item instanceof Bebida) {

                Bebida bebida = (Bebida) item;

                stmt.setString(3, "BEBIDA");
                stmt.setNull(4, Types.VARCHAR);
                stmt.setInt(5,
                            bebida.getTamanhoEmMl());
            }

            stmt.executeUpdate();

        } catch (SQLException e) {

            System.out.println(
                "Erro ao salvar: "
                + e.getMessage()
            );
        }
    }

    public List<ItemMenu> listarTodos() {

        List<ItemMenu> lista =
            new ArrayList<>();

        String sql =
            "SELECT * FROM item_menu";

        try (
            Connection conn =
                FabricaConexao.getConexao();

            PreparedStatement stmt =
                conn.prepareStatement(sql);

            ResultSet rs =
                stmt.executeQuery()
        ) {

            while (rs.next()) {

                String tipo =
                    rs.getString("tipo");

                if (tipo.equals("PIZZA")) {

                    Pizza pizza =
                        new Pizza();

                    pizza.setId(
                        rs.getInt("id")
                    );

                    pizza.setNome(
                        rs.getString("nome")
                    );

                    pizza.setPreco(
                        rs.getDouble("preco")
                    );

                    pizza.setIngredientes(
                        rs.getString(
                            "ingredientes"
                        )
                    );

                    lista.add(pizza);

                } else {

                    Bebida bebida =
                        new Bebida();

                    bebida.setId(
                        rs.getInt("id")
                    );

                    bebida.setNome(
                        rs.getString("nome")
                    );

                    bebida.setPreco(
                        rs.getDouble("preco")
                    );

                    bebida.setTamanhoEmMl(
                        rs.getInt(
                            "tamanho_ml"
                        )
                    );

                    lista.add(bebida);
                }
            }

        } catch (SQLException e) {

            System.out.println(
                "Erro ao listar: "
                + e.getMessage()
            );
        }

        return lista;
    }
}
