package view;

import dao.ItemMenuDAO;
import modelo.*;

import javax.swing.*;
import java.awt.*;

public class TelaPrincipal
        extends JFrame {

    private JTextField txtNome;
    private JTextField txtPreco;
    private JTextField txtExtra;
    private JComboBox<String> cbTipo;
    private JButton btnCadastrar;

    public TelaPrincipal() {

        setTitle("Sistema Pizzaria");

        setSize(450,300);

        setDefaultCloseOperation(
            EXIT_ON_CLOSE
        );

        setLocationRelativeTo(null);

        setLayout(
            new GridLayout(5,2)
        );

        txtNome = new JTextField();

        txtPreco = new JTextField();

        txtExtra = new JTextField();

        cbTipo =
            new JComboBox<>();

        cbTipo.addItem("Pizza");
        cbTipo.addItem("Bebida");

        btnCadastrar =
            new JButton(
                "Cadastrar Item"
            );

        add(new JLabel("Nome"));
        add(txtNome);

        add(new JLabel("Preço"));
        add(txtPreco);

        add(new JLabel("Tipo"));
        add(cbTipo);

        add(
            new JLabel(
                "Ingredientes ou ML"
            )
        );

        add(txtExtra);

        add(btnCadastrar);

        btnCadastrar
            .addActionListener(e -> {

                try {

                    String nome =
                        txtNome.getText();

                    double preco =
                        Double.parseDouble(
                            txtPreco.getText()
                        );

                    String tipo =
                        cbTipo
                        .getSelectedItem()
                        .toString();

                    ItemMenu item;

                    if (
                        tipo.equals(
                            "Pizza"
                        )
                    ) {

                        item =
                            new Pizza(
                                0,
                                nome,
                                preco,
                                txtExtra
                                .getText()
                            );

                    } else {

                        item =
                            new Bebida(
                                0,
                                nome,
                                preco,
                                Integer
                                .parseInt(
                                    txtExtra
                                    .getText()
                                )
                            );
                    }

                    ItemMenuDAO dao =
                        new ItemMenuDAO();

                    dao.salvar(item);

                    JOptionPane
                        .showMessageDialog(
                            null,
                            "Item cadastrado com sucesso!"
                        );

                } catch (Exception ex) {

                    JOptionPane
                        .showMessageDialog(
                            null,
                            "Erro: "
                            + ex.getMessage()
                        );
                }
            });

        setVisible(true);


    }

    

    public static void main(
        String[] args
    ) {

        new TelaPrincipal();
    }
}